<?php
//
//class MainController
//{
//    public $name;
//    public function __construct($name)
//    {
//        $this->name = $name;
//    }
//    public function viewData()
//    {
//        echo $this->name;
//    }
//}
//
//
//$object = new MainController('My name is Emon');
//$object->viewData();