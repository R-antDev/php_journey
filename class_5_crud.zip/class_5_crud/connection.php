<?php
$servername = 'localhost';
$username = 'root';
$password = '1234';
$database = 'formphp';
$port = 3307;


$conn = new mysqli($servername, $username, $password, $database, $port);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
